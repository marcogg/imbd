
const flores = [
    {
       idFlor: 1,
       titulo: 'Flores Blancas',
       descripcion: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores, debitis neque voluptatem mollitia totam animi nisi nemo, soluta excepturi assumenda esse quaerat maxime accusamus pariatur illo? Beatae soluta iure ipsum',
       imagen: './assets/img/img1.jpg'
    },
    {
        idFlor: 2,
        titulo: 'Flores Amarillas',
        descripcion: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores, debitis neque voluptatem mollitia totam animi nisi nemo, soluta excepturi assumenda esse quaerat maxime accusamus pariatur illo? Beatae soluta iure ipsum',
        imagen: './assets/img/img2.jpg'
     
     },
     {
        idFlor: 3,
        titulo: 'Flores Rojas',
        descripcion: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores, debitis neque voluptatem mollitia totam animi nisi nemo, soluta excepturi assumenda esse quaerat maxime accusamus pariatur illo? Beatae soluta iure ipsum',
        imagen: './assets/img/img3.jpg'
     
     }
]