let arr = [3,2,7,5,4,1]

// let num1 = arr[2]
// let num2 = arr[3]

let num1
let num2

[num1, num2] = [arr[2], arr[3]]